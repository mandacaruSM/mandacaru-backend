 
from django.apps import AppConfig

class AuthClienteConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'backend.apps.auth_cliente'
    verbose_name = 'Autenticação de Clientes'