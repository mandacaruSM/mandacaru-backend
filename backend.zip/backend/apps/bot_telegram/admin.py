# backend/apps/bot_telegram/admin.py
from django.contrib import admin