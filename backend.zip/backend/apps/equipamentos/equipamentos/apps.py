from django.apps import AppConfig
class EquipamentosConfig(AppConfig):
    name = 'backend.apps.equipamentos'
