# ================================================================
# ARQUIVO: backend/apps/nr12_checklist/urls.py
# ================================================================

from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views
from .views import visualizar_checklist_html


# Routers das APIs REST
router = DefaultRouter()
router.register(r'tipos-equipamento', views.TipoEquipamentoNR12ViewSet, basename='tipos-equipamento-nr12')
router.register(r'itens-padrao', views.ItemChecklistPadraoViewSet, basename='itens-padrao')
router.register(r'checklists', views.ChecklistNR12ViewSet, basename='checklists-nr12')
router.register(r'itens-checklist', views.ItemChecklistRealizadoViewSet, basename='itens-checklist')
router.register(r'alertas', views.AlertaManutencaoViewSet, basename='alertas-manutencao')

urlpatterns = [
    # Acesso rápido via QR Code (sem login)
    path('checklist/<uuid:checklist_uuid>/', views.checklist_por_uuid, name='checklist-uuid'),

    # Geração de PDF do checklist (pode ser usado no admin ou QR)
    path('checklist/<int:pk>/pdf/', visualizar_checklist_html, name='checklist-nr12-html'),



    # APIs REST autenticadas
    path('', include(router.urls)),
]
