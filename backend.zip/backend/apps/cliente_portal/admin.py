 
# backend/apps/cliente_portal/admin.py
from django.contrib import admin