 
from django.apps import AppConfig

class ClientePortalConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'backend.apps.cliente_portal'
    verbose_name = 'Portal do Cliente'