from django.apps import AppConfig
class FinanceiroConfig(AppConfig):
    name = 'backend.apps.financeiro'
