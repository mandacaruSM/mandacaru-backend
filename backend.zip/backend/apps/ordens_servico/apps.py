# backend/apps/ordens_servico/apps.py
from django.apps import AppConfig

class OrdensServicoConfig(AppConfig):
    name = 'backend.apps.ordens_servico'
    verbose_name = 'Ordens de Serviço'
