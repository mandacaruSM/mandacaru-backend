 
from django.apps import AppConfig

class Nr12ChecklistConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'backend.apps.nr12_checklist'
    verbose_name = 'Checklists NR12'
