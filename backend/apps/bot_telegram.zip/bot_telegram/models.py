# backend/apps/bot_telegram/models.py
from django.db import models